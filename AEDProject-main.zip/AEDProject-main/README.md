# AEDProject
Develop and testing software-based prototype of AED using Qt C++

Team Members:
Hoa Nguyen
Anne Dang
Marwan Atia-Elkaseh
Emi Chan 




